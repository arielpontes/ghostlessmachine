<?php
/**
* 
*/

/**
* 
*/
abstract class CJT_Framework_View_Block_Parameter_Base_Scalar
extends CJT_Framework_View_Block_Parameter_Base_Abstract {} // End class.