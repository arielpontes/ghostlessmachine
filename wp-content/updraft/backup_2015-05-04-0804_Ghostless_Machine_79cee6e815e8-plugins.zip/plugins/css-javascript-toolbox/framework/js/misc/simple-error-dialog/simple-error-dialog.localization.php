<?php
/**
* @version FILE_VERSION
* Localization file for jquery.block.js script.
*/

/**
* Localization for Javascript $VAR$ variable.
* 
* Localization text for backups script.
*/
return array(
	'dialogTitle' => cssJSToolbox::getText('Submission Error!'),
);