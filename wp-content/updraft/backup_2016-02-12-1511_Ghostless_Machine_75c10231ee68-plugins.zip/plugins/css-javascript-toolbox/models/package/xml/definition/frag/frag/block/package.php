<?php
/**
* 
*/

/**
* 
*/
class CJT_Models_Package_Xml_Definition_Frag_Frag_Block_Package
extends CJT_Models_Package_Xml_Definition_FragPackage {

	
	/**
	* put your comment there...
	* 
	* @var mixed
	*/
	protected $objectIdKeyName = 'blockId';
	
	/**
	* put your comment there...
	* 
	* @var mixed
	*/
	protected $objectTypeName = 'block';
	
	/**
	* put your comment there...
	* 
	* @var mixed
	*/
	protected $relationTypeName = 'add';
	
} // End class