<?php
/**
* 
*/

/**
* 
*/
class CJT_Models_Package_Xml_Definition_Package_Package_Objects
extends CJT_Models_Package_Xml_Definition_Abstract {}