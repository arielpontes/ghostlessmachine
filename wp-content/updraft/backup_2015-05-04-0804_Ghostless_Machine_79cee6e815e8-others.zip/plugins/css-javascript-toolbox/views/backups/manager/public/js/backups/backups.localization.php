<?php
/**
* @version FILE_VERSION
* Localization file for backups.js script.
*/

/**
* Localization text for backups script.
*/
return array(
	'BackupNameCannotBeNull' => cssJSToolbox::getText('Backup name cannot be null!'),
	'confirmDelete' => cssJSToolbox::getText('Would you like to delete "{BACKUP-NAME}" backup?'),	
);