<?php
/**
 * @package GoogleAnalytics
 * @subpackage Frontend
 */

?>
<!-- This site uses the Google Analytics by Yoast plugin v<?php echo GAWP_VERSION; ?> - https://yoast.com/wordpress/plugins/google-analytics/ -->
<!-- @Webmaster, normally you will find the Google Analytics tracking code here, but you have enabled the Debug Mode. Change that in Analytics -> (Tab) Debug mode and disable Debug Mode to enable the tracking of your site. -->
<!-- / Google Analytics by Yoast -->
