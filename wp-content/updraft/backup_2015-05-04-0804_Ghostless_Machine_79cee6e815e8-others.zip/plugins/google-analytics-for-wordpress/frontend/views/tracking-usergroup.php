<?php
/**
 * @package GoogleAnalytics
 * @subpackage Frontend
 */

?>
<!-- This site uses the Google Analytics by Yoast plugin v<?php echo GAWP_VERSION; ?> - https://yoast.com/wordpress/plugins/google-analytics/ -->
<!-- @Webmaster, normally you will find the Google Analytics tracking code here, but you are in the disabled user groups. Change that in Analytics -> Settings (Ignore usergroups) -->
<!-- / Google Analytics by Yoast -->
